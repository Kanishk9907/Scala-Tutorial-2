object two extends App{
  var a:Int=2;
  var b:Int=3;
  var c:Int=4;
  var d:Int=5;
  var k:Float=4.3f;
  

  //increment abd decrement method is not working in ubuntu

  //so here solve them using binary operators
  

  b-=1;
  println(b*a+c*d);
  d-=1;

  println(a);
  a+=1;

  //println(-2*(g-k)+c);   no value for g

  println(c);
  c+=1;

  c+=1;
  println(c*a);
  a+=1;



}
