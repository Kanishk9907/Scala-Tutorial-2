object first extends App{
  var i,j,k:Int=2;
  var m,n:Int=5;
  var f:Double=12.0f;
  var g:Double=4.0f
  var c:Char='X';
  var a:Int = k+12*m;
  var b:Double=m/j;
  var d:Int=n%j;
  var e:Double=m/j*j;
  var h:Double=f+10*5+g;
  var l:Double=(i+1)*n;

  println("a)"+a);
  println("b)"+b);
  println("c)"+d);
  println("d)"+e);
  println("e)"+h);
  println("f)"+l);
}
  
